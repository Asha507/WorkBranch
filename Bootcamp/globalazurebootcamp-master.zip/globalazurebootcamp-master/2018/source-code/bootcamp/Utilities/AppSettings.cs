﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace bootcamp.Utilities
{
    public class AppSettings
    {
        public string Location { get; set; }
    }
}
